import { useNavigate, useParams } from "react-router-dom";
import { useState, useEffect } from "react";

const FileDetails = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [file, setFile] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [bank, setBank] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [statusHistory, setStatusHistory] = useState([]);
  const [assignment, setAssignment] = useState(null);
  const [loading, setLoading] = useState(true);

  /* ---------------- LOAD DATA ---------------- */
  useEffect(() => {
    const files = JSON.parse(localStorage.getItem("loanFiles")) || [];
    const foundFile = files.find(f => String(f.id) === String(id));

    if (!foundFile) {
      alert("File not found");
      navigate(-1);
      return;
    }

    setFile(foundFile);

    // Load customer
    const customers = JSON.parse(localStorage.getItem("customers")) || [];
    const foundCustomer = customers.find(c => 
      String(c.id) === String(foundFile.customerId || foundFile.customer_id)
    );
    setCustomer(foundCustomer);

    // Load bank
    const banks = JSON.parse(localStorage.getItem("banks")) || [];
    const foundBank = banks.find(b => 
      b.name === (foundFile.bankName || foundFile.bank_name)
    );
    setBank(foundBank);

    // Load documents
    const docs = JSON.parse(localStorage.getItem("documents")) || [];
    const fileDocs = docs.filter(d => String(d.file_id) === String(id));
    setDocuments(fileDocs);

    // Load status history
    const history = JSON.parse(localStorage.getItem("statusHistory")) || [];
    const fileHistory = history.filter(h => String(h.file_id) === String(id));
    setStatusHistory(fileHistory);

    // Load assignment
    const assignments = JSON.parse(localStorage.getItem("executiveAssignments")) || [];
    const fileAssignment = assignments.find(a => String(a.file_id) === String(id));
    setAssignment(fileAssignment);

    setLoading(false);
  }, [id, navigate]);

  /* ---------------- FORMAT CURRENCY ---------------- */
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  /* ---------------- GET STATUS COLOR ---------------- */
  const getStatusColor = (status) => {
    const colors = {
      "In-Process": { bg: "#dbeafe", color: "#1e40af" },
      "Login": { bg: "#ede9fe", color: "#5b21b6" },
      "Query": { bg: "#fef3c7", color: "#92400e" },
      "Active": { bg: "#d1fae5", color: "#065f46" },
      "Sanctioned": { bg: "#dbeafe", color: "#1e40af" },
      "Rejected": { bg: "#fee2e2", color: "#991b1b" },
      "Disbursement": { bg: "#d1f4ff", color: "#0369a1" },
      "Completed": { bg: "#d1fae5", color: "#065f46" },
    };
    return colors[status] || { bg: "#f1f5f9", color: "#475569" };
  };

  /* ---------------- LOADING STATE ---------------- */
  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        fontSize: '1.5rem',
        color: '#64748b'
      }}>
        Loading file details...
      </div>
    );
  }

  if (!file) {
    return (
      <div style={{ 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        gap: '1rem'
      }}>
        <div style={{ fontSize: '4rem' }}>📁</div>
        <h2>File not found</h2>
        <button 
          onClick={() => navigate(-1)}
          style={{
            padding: '0.75rem 1.5rem',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: 600
          }}
        >
          Go Back
        </button>
      </div>
    );
  }

  const statusColor = getStatusColor(file.fileStatus || file.status);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

        .file-details-container {
          font-family: 'Inter', sans-serif;
          padding: 2rem;
          background: linear-gradient(135deg, #f5f7fa 0%, #f0f2f5 100%);
          min-height: 100vh;
        }

        /* Header */
        .page-header {
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          padding: 2rem;
          border-radius: 16px;
          margin-bottom: 2rem;
          box-shadow: 0 10px 30px rgba(59, 130, 246, 0.2);
        }

        .header-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }

        .back-btn {
          padding: 0.75rem 1.5rem;
          background: rgba(255, 255, 255, 0.2);
          color: white;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-radius: 10px;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .back-btn:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        .header-content {
          color: white;
        }

        .file-id {
          font-size: 2rem;
          font-weight: 900;
          margin: 0 0 0.5rem 0;
          font-family: monospace;
        }

        .file-meta {
          display: flex;
          gap: 1rem;
          align-items: center;
          flex-wrap: wrap;
        }

        .status-badge {
          padding: 0.5rem 1rem;
          border-radius: 8px;
          font-size: 0.875rem;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .file-date {
          font-size: 0.9rem;
          opacity: 0.9;
        }

        .quick-actions {
          display: flex;
          gap: 0.75rem;
        }

        .action-btn {
          padding: 0.75rem 1.5rem;
          border: none;
          border-radius: 10px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.9rem;
        }

        .btn-primary {
          background: white;
          color: #3b82f6;
        }

        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(255, 255, 255, 0.3);
        }

        .btn-secondary {
          background: rgba(255, 255, 255, 0.2);
          color: white;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .btn-secondary:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        /* Content Grid */
        .content-grid {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 2rem;
          margin-bottom: 2rem;
        }

        /* Info Cards */
        .info-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
          border: 1px solid #e2e8f0;
        }

        .card-title {
          font-size: 1.25rem;
          font-weight: 800;
          color: #0f172a;
          margin: 0 0 1.5rem 0;
          padding-bottom: 0.75rem;
          border-bottom: 2px solid #e2e8f0;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .info-grid {
          display: grid;
          gap: 1rem;
        }

        .info-row {
          display: flex;
          justify-content: space-between;
          padding: 0.75rem 0;
          border-bottom: 1px solid #f1f5f9;
        }

        .info-row:last-child {
          border-bottom: none;
        }

        .info-label {
          font-size: 0.875rem;
          color: #64748b;
          font-weight: 600;
        }

        .info-value {
          font-size: 0.875rem;
          color: #0f172a;
          font-weight: 700;
          text-align: right;
        }

        .amount-value {
          font-size: 1.25rem;
          color: #3b82f6;
          font-family: monospace;
        }

        /* Sidebar Cards */
        .sidebar-section {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }

        .summary-card {
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          color: white;
          padding: 1.5rem;
          border-radius: 12px;
          box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
        }

        .summary-title {
          font-size: 1rem;
          font-weight: 700;
          margin: 0 0 1rem 0;
          opacity: 0.9;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .summary-item {
          padding: 0.75rem 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .summary-item:last-child {
          border-bottom: none;
        }

        .summary-label {
          font-size: 0.75rem;
          opacity: 0.8;
          margin-bottom: 0.25rem;
        }

        .summary-value {
          font-size: 1rem;
          font-weight: 700;
        }

        /* Documents Section */
        .documents-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
          border: 1px solid #e2e8f0;
          margin-bottom: 2rem;
        }

        .doc-list {
          display: grid;
          gap: 1rem;
        }

        .doc-item {
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          padding: 1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          transition: all 0.3s;
        }

        .doc-item:hover {
          border-color: #3b82f6;
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
        }

        .doc-info {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .doc-icon {
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.25rem;
        }

        .doc-details h4 {
          font-size: 0.95rem;
          font-weight: 700;
          color: #0f172a;
          margin: 0 0 0.25rem 0;
        }

        .doc-details p {
          font-size: 0.8rem;
          color: #64748b;
          margin: 0;
        }

        .doc-badge {
          padding: 0.375rem 0.75rem;
          border-radius: 6px;
          font-size: 0.75rem;
          font-weight: 700;
          text-transform: uppercase;
        }

        .badge-approved {
          background: #d1fae5;
          color: #065f46;
        }

        .badge-rejected {
          background: #fee2e2;
          color: #991b1b;
        }

        .badge-pending {
          background: #fef3c7;
          color: #92400e;
        }

        /* Status History */
        .history-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
          border: 1px solid #e2e8f0;
        }

        .timeline {
          position: relative;
          padding-left: 2rem;
        }

        .timeline::before {
          content: '';
          position: absolute;
          left: 8px;
          top: 0;
          bottom: 0;
          width: 2px;
          background: linear-gradient(to bottom, #3b82f6, #e2e8f0);
        }

        .timeline-item {
          position: relative;
          padding-bottom: 1.5rem;
        }

        .timeline-item:last-child {
          padding-bottom: 0;
        }

        .timeline-dot {
          position: absolute;
          left: -1.875rem;
          top: 0;
          width: 18px;
          height: 18px;
          background: white;
          border: 3px solid #3b82f6;
          border-radius: 50%;
          box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .timeline-content {
          background: #f8fafc;
          padding: 1rem;
          border-radius: 10px;
          border: 1px solid #e2e8f0;
        }

        .timeline-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.5rem;
        }

        .timeline-status {
          font-weight: 700;
          color: #0f172a;
        }

        .timeline-date {
          font-size: 0.75rem;
          color: #64748b;
        }

        .timeline-remark {
          font-size: 0.875rem;
          color: #475569;
          margin-top: 0.5rem;
        }

        .empty-state {
          text-align: center;
          padding: 3rem 2rem;
          color: #64748b;
        }

        .empty-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
          opacity: 0.5;
        }

        @media (max-width: 1200px) {
          .content-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 768px) {
          .file-details-container {
            padding: 1rem;
          }

          .header-top {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .quick-actions {
            width: 100%;
            flex-direction: column;
          }

          .action-btn {
            width: 100%;
            justify-content: center;
          }
        }
      `}</style>

      <div className="file-details-container">
        {/* Header */}
        <div className="page-header">
          <div className="header-top">
            <button className="back-btn" onClick={() => navigate(-1)}>
              <span>←</span>
              <span>Back</span>
            </button>
            <div className="quick-actions">
              <button 
                className="action-btn btn-primary"
                onClick={() => navigate(`/admin/status/update`)}
              >
                <span>🔄</span>
                <span>Update Status</span>
              </button>
              <button 
                className="action-btn btn-secondary"
                onClick={() => navigate(`/admin/documents`)}
              >
                <span>📄</span>
                <span>View Documents</span>
              </button>
            </div>
          </div>
          <div className="header-content">
            <h1 className="file-id">File #{file.id}</h1>
            <div className="file-meta">
              <div 
                className="status-badge" 
                style={{ 
                  background: statusColor.bg, 
                  color: statusColor.color 
                }}
              >
                {file.fileStatus || file.status || "New"}
              </div>
              <div className="file-date">
                Created: {file.createdDate || file.date_of_registration || file.created_date || "N/A"}
              </div>
            </div>
          </div>
        </div>

        {/* Content Grid */}
        <div className="content-grid">
          {/* Left Column */}
          <div>
            {/* Customer Information */}
            <div className="info-card">
              <h2 className="card-title">
                <span>👤</span>
                <span>Customer Information</span>
              </h2>
              <div className="info-grid">
                <div className="info-row">
                  <span className="info-label">Customer Name</span>
                  <span className="info-value">
                    {customer?.name || file.customerName || file.customer_name || "N/A"}
                  </span>
                </div>
                <div className="info-row">
                  <span className="info-label">Email</span>
                  <span className="info-value">{customer?.email || "N/A"}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Phone</span>
                  <span className="info-value">
                    {customer?.phone || customer?.mobile || customer?.contact || "N/A"}
                  </span>
                </div>
                <div className="info-row">
                  <span className="info-label">WhatsApp</span>
                  <span className="info-value">{customer?.whatsapp || "N/A"}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Address</span>
                  <span className="info-value">
                    {customer?.city || "N/A"}, {customer?.pincode || "N/A"}
                  </span>
                </div>
              </div>
            </div>

            {/* Loan Information */}
            <div className="info-card" style={{ marginTop: '1.5rem' }}>
              <h2 className="card-title">
                <span>💰</span>
                <span>Loan Information</span>
              </h2>
              <div className="info-grid">
                <div className="info-row">
                  <span className="info-label">Loan Type</span>
                  <span className="info-value">{file.loanType || file.loan_type}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Loan Amount</span>
                  <span className="info-value amount-value">
                    {formatCurrency(file.amount || file.loanAmount || 0)}
                  </span>
                </div>
                <div className="info-row">
                  <span className="info-label">Bank</span>
                  <span className="info-value">{file.bankName || file.bank_name}</span>
                </div>
                {bank && (
                  <>
                    <div className="info-row">
                      <span className="info-label">Branch</span>
                      <span className="info-value">{bank.branch || "N/A"}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Contact Person</span>
                      <span className="info-value">{bank.contact_person || "N/A"}</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Assignment Information */}
            {assignment && (
              <div className="info-card" style={{ marginTop: '1.5rem' }}>
                <h2 className="card-title">
                  <span>👨‍💼</span>
                  <span>Assignment Information</span>
                </h2>
                <div className="info-grid">
                  <div className="info-row">
                    <span className="info-label">Assigned To</span>
                    <span className="info-value">{assignment.executive_name}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Email</span>
                    <span className="info-value">{assignment.executive_email}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Phone</span>
                    <span className="info-value">{assignment.executive_phone}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Assigned Date</span>
                    <span className="info-value">{assignment.assigned_date}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Status</span>
                    <span className="info-value">{assignment.assignment_status}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="sidebar-section">
            {/* Summary Card */}
            <div className="summary-card">
              <h3 className="summary-title">Quick Summary</h3>
              <div className="summary-item">
                <div className="summary-label">File Status</div>
                <div className="summary-value">{file.fileStatus || file.status || "New"}</div>
              </div>
              <div className="summary-item">
                <div className="summary-label">Loan Amount</div>
                <div className="summary-value">
                  {formatCurrency(file.amount || file.loanAmount || 0)}
                </div>
              </div>
              <div className="summary-item">
                <div className="summary-label">Documents</div>
                <div className="summary-value">{documents.length} Uploaded</div>
              </div>
              <div className="summary-item">
                <div className="summary-label">Status Changes</div>
                <div className="summary-value">{statusHistory.length} Updates</div>
              </div>
            </div>

            {/* Statistics */}
            <div className="info-card">
              <h3 className="card-title">
                <span>📊</span>
                <span>Statistics</span>
              </h3>
              <div className="info-grid">
                <div className="info-row">
                  <span className="info-label">Documents Uploaded</span>
                  <span className="info-value">{documents.length}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Documents Verified</span>
                  <span className="info-value">
                    {documents.filter(d => d.verification_status === "Approved").length}
                  </span>
                </div>
                <div className="info-row">
                  <span className="info-label">Documents Pending</span>
                  <span className="info-value">
                    {documents.filter(d => !d.verification_status || d.verification_status === "Pending").length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Documents Section */}
        <div className="documents-card">
          <h2 className="card-title">
            <span>📎</span>
            <span>Uploaded Documents ({documents.length})</span>
          </h2>
          {documents.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📄</div>
              <h3>No documents uploaded</h3>
              <p>Documents will appear here once uploaded</p>
            </div>
          ) : (
            <div className="doc-list">
              {documents.map((doc) => (
                <div key={doc.id} className="doc-item">
                  <div className="doc-info">
                    <div className="doc-icon">📄</div>
                    <div className="doc-details">
                      <h4>{doc.name || doc.document_name}</h4>
                      <p>
                        {doc.type || doc.document_type} • Uploaded on {doc.date || doc.submission_date}
                      </p>
                    </div>
                  </div>
                  <div
                    className={`doc-badge badge-${
                      doc.verification_status === "Approved"
                        ? "approved"
                        : doc.verification_status === "Rejected"
                        ? "rejected"
                        : "pending"
                    }`}
                  >
                    {doc.verification_status || "Pending"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Status History */}
        <div className="history-card">
          <h2 className="card-title">
            <span>🕐</span>
            <span>Status History ({statusHistory.length} updates)</span>
          </h2>
          {statusHistory.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📋</div>
              <h3>No status updates yet</h3>
              <p>Status change history will appear here</p>
            </div>
          ) : (
            <div className="timeline">
              {statusHistory.slice().reverse().map((item, index) => (
                <div key={index} className="timeline-item">
                  <div className="timeline-dot"></div>
                  <div className="timeline-content">
                    <div className="timeline-header">
                      <span className="timeline-status">
                        {item.old_status} → {item.new_status}
                      </span>
                      <span className="timeline-date">
                        {item.date} {item.time}
                      </span>
                    </div>
                    {item.description && (
                      <div className="timeline-remark">
                        <strong>Description:</strong> {item.description}
                      </div>
                    )}
                    {item.remark && (
                      <div className="timeline-remark">
                        <strong>Remark:</strong> {item.remark}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default FileDetails;