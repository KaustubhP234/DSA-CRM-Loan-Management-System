const Dashboard = () => {
  return (
    <div style={{ padding: "80px", textAlign: "center" }}>
      <h1>Dashboard</h1>
      <p>Role-based dashboard will be built here.</p>
    </div>
  );
};

export default Dashboard;
