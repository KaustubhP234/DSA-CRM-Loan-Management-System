import { useState, useEffect } from "react";

const Documents = () => {
  const [documents, setDocuments] = useState([]);
  const [filteredDocuments, setFilteredDocuments] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [filterType, setFilterType] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    loadDocuments();
    window.addEventListener("focus", loadDocuments);
    return () => window.removeEventListener("focus", loadDocuments);
  }, []);

  useEffect(() => {
    filterDocuments();
  }, [searchTerm, filterStatus, filterType, documents]);

  const loadDocuments = () => {
    const storedDocuments = JSON.parse(localStorage.getItem("documents"));
    
    if (!storedDocuments || storedDocuments.length === 0) {
      setDocuments([]);
      setFilteredDocuments([]);
    } else {
      // Auto-fix documents with incorrect file_id
      const files = JSON.parse(localStorage.getItem("loanFiles")) || [];
      const fixedDocuments = storedDocuments.map(doc => {
        // Fix old format file IDs
        if (doc.file_id && (doc.file_id.startsWith("FILE") || doc.file_id.startsWith("CUST"))) {
          const matchingFile = files.find(f => 
            (f.customerName || f.customer_name || "").toLowerCase() === (doc.customer_name || "").toLowerCase()
          );
          
          if (matchingFile) {
            return {
              ...doc,
              file_id: matchingFile.id,
              fileId: matchingFile.id
            };
          }
        }
        return doc;
      });
      
      if (JSON.stringify(fixedDocuments) !== JSON.stringify(storedDocuments)) {
        localStorage.setItem("documents", JSON.stringify(fixedDocuments));
      }
      
      setDocuments(fixedDocuments);
      setFilteredDocuments(fixedDocuments);
    }
  };

  const filterDocuments = () => {
    let filtered = [...documents];

    if (searchTerm) {
      filtered = filtered.filter(
        (doc) =>
          (doc.doc_id || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.customer_name || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.file_id || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.type || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.doc_number || "").toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterStatus !== "All") {
      filtered = filtered.filter((doc) => doc.status === filterStatus);
    }

    if (filterType !== "All") {
      filtered = filtered.filter((doc) => doc.type === filterType);
    }

    setFilteredDocuments(filtered);
    setCurrentPage(1);
  };

  const handleDelete = (docId) => {
    if (window.confirm("⚠️ Are you sure you want to delete this document?\n\nThis action cannot be undone!")) {
      const updatedDocuments = documents.filter((doc) => doc.id !== docId);
      localStorage.setItem("documents", JSON.stringify(updatedDocuments));
      setDocuments(updatedDocuments);
      alert("✅ Document deleted successfully!");
    }
  };

  const getStatusBadgeColor = (status) => {
    const colors = {
      Approved: "status-approved",
      Pending: "status-pending",
      Rejected: "status-rejected",
      "Under Review": "status-review",
    };
    return colors[status] || "status-default";
  };

  const getDocTypeIcon = (type) => {
    const icons = {
      "Aadhaar Card": "🆔",
      "Aadhar Card": "🆔",
      "PAN Card": "💳",
      "Bank Statement": "🏦",
      "Salary Slip": "💰",
      "Property Documents": "🏠",
      "Income Proof": "📊",
      "Address Proof": "📍",
      "ITR": "📝",
      "Form 16": "📋",
      "Business Documents": "💼",
      "Passport": "🛂",
      "Driving License": "🚗",
      "Voter ID": "🗳️",
      "Identity Proof": "🆔",
      "Other": "📄",
    };
    return icons[type] || "📄";
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredDocuments.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .documents-container {
          padding: 32px;
          background: #f8fafc;
          min-height: 100vh;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 32px;
        }

        .header-content h1 {
          font-size: 32px;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 8px;
          letter-spacing: -0.02em;
        }

        .header-content p {
          font-size: 15px;
          color: #64748b;
        }

        .upload-btn {
          padding: 12px 24px;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          color: white;
          border: none;
          border-radius: 10px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
          transition: all 0.3s ease;
        }

        .upload-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(16, 185, 129, 0.35);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
          margin-bottom: 32px;
        }

        .stat-card {
          background: white;
          border-radius: 12px;
          padding: 24px;
          border: 1px solid #e2e8f0;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          transition: all 0.3s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        .stat-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 16px;
        }

        .stat-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
        }

        .stat-label {
          font-size: 13px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 8px;
        }

        .stat-value {
          font-size: 28px;
          font-weight: 800;
          color: #0f172a;
          letter-spacing: -0.02em;
          font-family: 'JetBrains Mono', monospace;
        }

        .filters-section {
          background: white;
          border-radius: 12px;
          padding: 20px;
          border: 1px solid #e2e8f0;
          margin-bottom: 24px;
          display: flex;
          gap: 16px;
          align-items: center;
        }

        .search-wrapper {
          flex: 1;
          position: relative;
        }

        .search-icon {
          position: absolute;
          left: 16px;
          top: 50%;
          transform: translateY(-50%);
          font-size: 18px;
          color: #94a3b8;
        }

        .search-input {
          width: 100%;
          padding: 12px 16px 12px 48px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          font-family: 'Inter', sans-serif;
          transition: all 0.3s;
        }

        .search-input:focus {
          outline: none;
          border-color: #10b981;
          box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }

        .filter-select {
          padding: 12px 16px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 500;
          font-family: 'Inter', sans-serif;
          cursor: pointer;
          min-width: 160px;
          transition: all 0.3s;
        }

        .filter-select:focus {
          outline: none;
          border-color: #10b981;
        }

        .table-container {
          background: white;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
          overflow: hidden;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        table {
          width: 100%;
          border-collapse: collapse;
        }

        thead {
          background: #f8fafc;
          border-bottom: 2px solid #e2e8f0;
        }

        th {
          padding: 16px 20px;
          text-align: left;
          font-size: 12px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        tbody tr {
          border-bottom: 1px solid #f1f5f9;
          transition: all 0.2s;
        }

        tbody tr:hover {
          background: #f8fafc;
        }

        td {
          padding: 20px;
          font-size: 14px;
          color: #334155;
        }

        .doc-info {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .doc-icon-wrapper {
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #10b981, #059669);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
        }

        .doc-details {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .doc-id {
          font-weight: 600;
          color: #0f172a;
        }

        .doc-type {
          font-size: 12px;
          color: #64748b;
        }

        .customer-info {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .customer-name {
          font-weight: 600;
          color: #0f172a;
        }

        .customer-id {
          font-size: 12px;
          color: #64748b;
        }

        .file-badge {
          display: inline-block;
          padding: 6px 12px;
          background: #dbeafe;
          color: #1e40af;
          border-radius: 6px;
          font-weight: 600;
          font-size: 13px;
          font-family: 'JetBrains Mono', monospace;
          border: 1px solid #bfdbfe;
        }

        .doc-number {
          font-family: 'JetBrains Mono', monospace;
          font-size: 13px;
          background: #f1f5f9;
          padding: 6px 12px;
          border-radius: 6px;
          color: #475569;
          font-weight: 500;
          border: 1px solid #e2e8f0;
        }

        .status-badge {
          display: inline-flex;
          padding: 6px 14px;
          border-radius: 16px;
          font-size: 13px;
          font-weight: 600;
        }

        .status-approved {
          background: #d1fae5;
          color: #065f46;
          border: 1px solid #6ee7b7;
        }

        .status-pending {
          background: #fef3c7;
          color: #92400e;
          border: 1px solid #fcd34d;
        }

        .status-rejected {
          background: #fee2e2;
          color: #991b1b;
          border: 1px solid #fca5a5;
        }

        .status-review {
          background: #dbeafe;
          color: #1e40af;
          border: 1px solid #93c5fd;
        }

        .action-buttons {
          display: flex;
          gap: 8px;
        }

        .action-btn {
          width: 32px;
          height: 32px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          font-size: 16px;
        }

        .action-view {
          background: #dbeafe;
          border: 1px solid #bfdbfe;
        }

        .action-view:hover {
          background: #3b82f6;
          transform: translateY(-1px);
        }

        .action-edit {
          background: #fef3c7;
          border: 1px solid #fde68a;
        }

        .action-edit:hover {
          background: #f59e0b;
          transform: translateY(-1px);
        }

        .action-delete {
          background: #fee2e2;
          border: 1px solid #fecaca;
        }

        .action-delete:hover {
          background: #ef4444;
          transform: translateY(-1px);
        }

        .no-data {
          padding: 80px 20px;
          text-align: center;
        }

        .no-data-icon {
          font-size: 64px;
          margin-bottom: 16px;
          opacity: 0.5;
        }

        .no-data-title {
          font-size: 18px;
          font-weight: 600;
          color: #0f172a;
          margin-bottom: 8px;
        }

        .no-data-text {
          font-size: 14px;
          color: #64748b;
        }

        @media (max-width: 1200px) {
          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 768px) {
          .documents-container {
            padding: 16px;
          }
          .stats-grid {
            grid-template-columns: 1fr;
          }
          .page-header {
            flex-direction: column;
            gap: 16px;
          }
          .filters-section {
            flex-direction: column;
          }
          .table-container {
            overflow-x: auto;
          }
        }
      `}</style>

      <div className="documents-container">
        <div className="page-header">
          <div className="header-content">
            <h1>Document Management</h1>
            <p>Manage and verify customer documents for loan applications</p>
          </div>
          <button className="upload-btn" onClick={() => (window.location.href = "/admin/upload-document")}>
            <span style={{ fontSize: "20px" }}>+</span>
            Upload Document
          </button>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon" style={{ background: "rgba(139, 92, 246, 0.1)" }}>📊</div>
            </div>
            <div className="stat-label">Total Documents</div>
            <div className="stat-value">{documents.length}</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon" style={{ background: "rgba(16, 185, 129, 0.1)" }}>✅</div>
            </div>
            <div className="stat-label">Approved</div>
            <div className="stat-value">{documents.filter((d) => d.status === "Approved").length}</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon" style={{ background: "rgba(245, 158, 11, 0.1)" }}>⏳</div>
            </div>
            <div className="stat-label">Pending Review</div>
            <div className="stat-value">{documents.filter((d) => d.status === "Pending" || d.status === "Under Review").length}</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon" style={{ background: "rgba(239, 68, 68, 0.1)" }}>❌</div>
            </div>
            <div className="stat-label">Rejected</div>
            <div className="stat-value">{documents.filter((d) => d.status === "Rejected").length}</div>
          </div>
        </div>

        <div className="filters-section">
          <div className="search-wrapper">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by Doc ID, Customer, File ID, Type..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select className="filter-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Approved">Approved</option>
            <option value="Pending">Pending</option>
            <option value="Rejected">Rejected</option>
            <option value="Under Review">Under Review</option>
          </select>
          <select className="filter-select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
            <option value="All">All Types</option>
            <option value="Aadhaar Card">Aadhaar Card</option>
            <option value="PAN Card">PAN Card</option>
            <option value="Bank Statement">Bank Statement</option>
            <option value="Salary Slip">Salary Slip</option>
          </select>
        </div>

        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Document Info</th>
                <th>Customer Details</th>
                <th>File ID</th>
                <th>Document Number</th>
                <th>Submission Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.length === 0 ? (
                <tr>
                  <td colSpan="7">
                    <div className="no-data">
                      <div className="no-data-icon">📭</div>
                      <div className="no-data-title">No documents found</div>
                      <div className="no-data-text">Upload documents to get started or adjust your filters</div>
                    </div>
                  </td>
                </tr>
              ) : (
                currentItems.map((doc) => (
                  <tr key={doc.id}>
                    <td>
                      <div className="doc-info">
                        <div className="doc-icon-wrapper">{getDocTypeIcon(doc.type)}</div>
                        <div className="doc-details">
                          <span className="doc-id">{doc.doc_id || doc.id}</span>
                          <span className="doc-type">{doc.type || doc.document_type}</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="customer-info">
                        <span className="customer-name">{doc.customer_name}</span>
                        <span className="customer-id">{doc.customer_id}</span>
                      </div>
                    </td>
                    <td>
                      <span className="file-badge">{doc.file_id}</span>
                    </td>
                    <td>
                      <code className="doc-number">{doc.doc_number || doc.document_number || "N/A"}</code>
                    </td>
                    <td>
                      {doc.date_of_submission || doc.date || doc.submission_date ? 
                        new Date(doc.date_of_submission || doc.date || doc.submission_date).toLocaleDateString("en-IN", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        }) : "N/A"}
                    </td>
                    <td>
                      <span className={`status-badge ${getStatusBadgeColor(doc.status || "Pending")}`}>
                        {doc.status || "Pending"}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button onClick={() => (window.location.href = `/admin/documents/${doc.id}`)} className="action-btn action-view" title="View">👁️</button>
                        <button onClick={() => alert("Edit coming soon!")} className="action-btn action-edit" title="Edit">✏️</button>
                        <button onClick={() => handleDelete(doc.id)} className="action-btn action-delete" title="Delete">🗑️</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default Documents;