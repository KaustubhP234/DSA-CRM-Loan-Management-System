import { useState, useEffect } from "react";

const UploadDocument = () => {
  const [formData, setFormData] = useState({
    documentType: "",
    documentName: "",
    documentNumber: "",
    fileId: "",
    customerId: "",
    description: "",
    remark: "",
  });

  const [files, setFiles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    const loadedFiles = JSON.parse(localStorage.getItem("loanFiles")) || [];
    const loadedCustomers = JSON.parse(localStorage.getItem("customers")) || [];
    
    setFiles(loadedFiles);
    setCustomers(loadedCustomers);
  }, []);

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => String(c.id) === String(customerId));
    return customer ? customer.name : "";
  };

  const getFileInfo = (fileId) => {
    return files.find(f => String(f.id) === String(fileId));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ""
      }));
    }

    if (name === "fileId" && value) {
      const file = getFileInfo(value);
      if (file) {
        const customerId = file.customerId || file.customer_id;
        setFormData(prev => ({
          ...prev,
          customerId: customerId || ""
        }));
      }
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.documentType) {
      newErrors.documentType = "Please select document type";
    }

    if (!formData.documentName) {
      newErrors.documentName = "Document name is required";
    }

    if (!formData.fileId) {
      newErrors.fileId = "Please select a file ID";
    }

    if (!formData.customerId) {
      newErrors.customerId = "Customer ID is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) {
      return;
    }

    setLoading(true);

    try {
      const selectedFile = getFileInfo(formData.fileId);
      const customerName = getCustomerName(formData.customerId);

      const existingDocuments = JSON.parse(localStorage.getItem("documents")) || [];
      
      const newDocId = existingDocuments.length > 0
        ? Math.max(...existingDocuments.map(d => d.id || 0)) + 1
        : 1;

      const docIdString = `DOC${String(newDocId).padStart(3, '0')}`;

      const newDocument = {
        id: newDocId,
        doc_id: docIdString,
        type: formData.documentType,
        document_type: formData.documentType,
        name: formData.documentName,
        document_name: formData.documentName,
        doc_number: formData.documentNumber,
        document_number: formData.documentNumber,
        file_id: formData.fileId,
        fileId: formData.fileId,
        customer_id: formData.customerId,
        customerId: formData.customerId,
        customer_name: customerName,
        customerName: customerName,
        date_of_submission: new Date().toISOString().split('T')[0],
        date: new Date().toISOString().split('T')[0],
        submission_date: new Date().toISOString().split('T')[0],
        description: formData.description || "",
        remark: formData.remark || "",
        status: "Pending",
        verification_status: "Pending",
        verified_by: "",
        verification_date: "",
        verification_remarks: "",
      };

      const updatedDocuments = [...existingDocuments, newDocument];
      localStorage.setItem("documents", JSON.stringify(updatedDocuments));

      alert(`✅ Document uploaded successfully!\n\nDocument ID: ${docIdString}\nFile ID: ${formData.fileId}\nCustomer: ${customerName}`);

      setFormData({
        documentType: "",
        documentName: "",
        documentNumber: "",
        fileId: "",
        customerId: "",
        description: "",
        remark: "",
      });

      setTimeout(() => {
        window.location.href = "/admin/documents";
      }, 500);

    } catch (error) {
      console.error("Error uploading document:", error);
      alert("❌ Error uploading document. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const documentTypes = [
    "Aadhaar Card",
    "PAN Card",
    "Bank Statement",
    "Salary Slip",
    "Property Documents",
    "Income Proof",
    "Address Proof",
    "ITR",
    "Form 16",
    "Business Documents",
    "Passport",
    "Driving License",
    "Voter ID",
    "Identity Proof",
    "Other",
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .upload-container {
          padding: 32px;
          background: #f8fafc;
          min-height: 100vh;
          max-width: 1200px;
          margin: 0 auto;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 32px;
        }

        .header-content h1 {
          font-size: 32px;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 8px;
          letter-spacing: -0.02em;
        }

        .header-content p {
          font-size: 15px;
          color: #64748b;
        }

        .back-btn {
          padding: 10px 20px;
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .back-btn:hover {
          background: #f8fafc;
          border-color: #cbd5e1;
        }

        .info-alert {
          background: linear-gradient(135deg, #d1fae5, #a7f3d0);
          border: 2px solid #10b981;
          border-radius: 12px;
          padding: 16px 20px;
          margin-bottom: 32px;
          display: flex;
          gap: 12px;
          align-items: start;
        }

        .alert-icon {
          font-size: 24px;
          flex-shrink: 0;
        }

        .alert-content {
          flex: 1;
        }

        .alert-title {
          font-size: 14px;
          font-weight: 700;
          color: #065f46;
          margin-bottom: 6px;
        }

        .alert-text {
          font-size: 13px;
          color: #047857;
          line-height: 1.6;
        }

        .form-card {
          background: white;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
          padding: 32px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .form-section {
          margin-bottom: 32px;
        }

        .section-title {
          font-size: 18px;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 20px;
          padding-bottom: 12px;
          border-bottom: 2px solid #e2e8f0;
        }

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
        }

        .form-group-full {
          grid-column: 1 / -1;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .form-label {
          font-size: 13px;
          font-weight: 600;
          color: #334155;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .required {
          color: #ef4444;
        }

        .form-input,
        .form-select,
        .form-textarea {
          padding: 12px 16px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 500;
          transition: all 0.3s;
          background: #f8fafc;
          font-family: 'Inter', sans-serif;
        }

        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
          outline: none;
          border-color: #10b981;
          background: white;
          box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }

        .form-input.error,
        .form-select.error {
          border-color: #ef4444;
          background: #fef2f2;
        }

        .form-textarea {
          min-height: 100px;
          resize: vertical;
        }

        .form-help {
          font-size: 12px;
          color: #64748b;
        }

        .error-message {
          font-size: 12px;
          color: #ef4444;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .file-info-card {
          background: linear-gradient(135deg, #f8fafc, #f1f5f9);
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 20px;
          margin-top: 24px;
        }

        .file-info-title {
          font-size: 14px;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .file-info-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .file-info-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .file-info-label {
          font-size: 11px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .file-info-value {
          font-size: 14px;
          color: #0f172a;
          font-weight: 600;
        }

        .form-actions {
          display: flex;
          gap: 16px;
          margin-top: 32px;
          padding-top: 24px;
          border-top: 2px solid #e2e8f0;
        }

        .btn-cancel {
          flex: 1;
          padding: 14px;
          background: white;
          color: #475569;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
          font-size: 15px;
        }

        .btn-cancel:hover {
          background: #f8fafc;
          border-color: #cbd5e1;
        }

        .btn-submit {
          flex: 1;
          padding: 14px;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          color: white;
          border: none;
          border-radius: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
          font-size: 15px;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
        }

        .btn-submit:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(16, 185, 129, 0.35);
        }

        .btn-submit:disabled {
          opacity: 0.5;
          cursor: not-allowed;
          transform: none;
        }

        @media (max-width: 768px) {
          .upload-container {
            padding: 16px;
          }

          .form-card {
            padding: 20px;
          }

          .form-grid {
            grid-template-columns: 1fr;
          }

          .page-header {
            flex-direction: column;
            gap: 16px;
          }

          .file-info-grid {
            grid-template-columns: 1fr;
          }

          .form-actions {
            flex-direction: column-reverse;
          }
        }
      `}</style>

      <div className="upload-container">
        {/* Header */}
        <div className="page-header">
          <div className="header-content">
            <h1>Upload Document</h1>
            <p>Upload and link documents to loan files</p>
          </div>
          <button className="back-btn" onClick={() => (window.location.href = "/admin/documents")}>
            <span>←</span>
            Back to Documents
          </button>
        </div>

        {/* Info Alert */}
        <div className="info-alert">
          <span className="alert-icon">💡</span>
          <div className="alert-content">
            <div className="alert-title">Document Upload Guidelines</div>
            <div className="alert-text">
              • Select the loan file to link this document to<br/>
              • Provide accurate document details for verification<br/>
              • Document will be marked as "Pending" until verified by admin
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="form-card">
          {/* Basic Information */}
          <div className="form-section">
            <h2 className="section-title">Basic Information</h2>
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">
                  Document Type <span className="required">*</span>
                </label>
                <select
                  name="documentType"
                  value={formData.documentType}
                  onChange={handleChange}
                  className={`form-select ${errors.documentType ? 'error' : ''}`}
                >
                  <option value="">-- Select Document Type --</option>
                  {documentTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                {errors.documentType && (
                  <span className="error-message">⚠️ {errors.documentType}</span>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">
                  Document Name <span className="required">*</span>
                </label>
                <input
                  type="text"
                  name="documentName"
                  value={formData.documentName}
                  onChange={handleChange}
                  className={`form-input ${errors.documentName ? 'error' : ''}`}
                  placeholder="e.g., Aadhaar Card Front"
                />
                {errors.documentName && (
                  <span className="error-message">⚠️ {errors.documentName}</span>
                )}
                <span className="form-help">Enter a descriptive name for the document</span>
              </div>

              <div className="form-group-full">
                <label className="form-label">
                  Document Number
                </label>
                <input
                  type="text"
                  name="documentNumber"
                  value={formData.documentNumber}
                  onChange={handleChange}
                  className="form-input"
                  placeholder="e.g., ABCD1234E or 1234-5678-9012"
                />
                <span className="form-help">Enter the document number (e.g., PAN number, Aadhaar number)</span>
              </div>
            </div>
          </div>

          {/* File & Customer Linking */}
          <div className="form-section">
            <h2 className="section-title">File & Customer Linking</h2>
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">
                  File ID <span className="required">*</span>
                </label>
                <select
                  name="fileId"
                  value={formData.fileId}
                  onChange={handleChange}
                  className={`form-select ${errors.fileId ? 'error' : ''}`}
                >
                  <option value="">-- Select Loan File --</option>
                  {files.map(file => (
                    <option key={file.id} value={file.id}>
                      {file.id} - {file.customerName || file.customer_name} ({file.loanType || file.loan_type})
                    </option>
                  ))}
                </select>
                {errors.fileId && (
                  <span className="error-message">⚠️ {errors.fileId}</span>
                )}
                {files.length === 0 && (
                  <span className="form-help" style={{ color: "#ef4444" }}>
                    No loan files available. Please create loan files first.
                  </span>
                )}
                {files.length > 0 && (
                  <span className="form-help">Select the loan file this document belongs to</span>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">
                  Customer ID <span className="required">*</span>
                </label>
                <select
                  name="customerId"
                  value={formData.customerId}
                  onChange={handleChange}
                  className={`form-select ${errors.customerId ? 'error' : ''}`}
                >
                  <option value="">-- Select Customer --</option>
                  {customers.map(customer => (
                    <option key={customer.id} value={customer.id}>
                      {customer.id} - {customer.name}
                    </option>
                  ))}
                </select>
                {errors.customerId && (
                  <span className="error-message">⚠️ {errors.customerId}</span>
                )}
                <span className="form-help">Auto-populated when file is selected</span>
              </div>
            </div>

            {/* File Info Display */}
            {formData.fileId && getFileInfo(formData.fileId) && (
              <div className="file-info-card">
                <div className="file-info-title">
                  <span>📋</span>
                  Selected File Information
                </div>
                <div className="file-info-grid">
                  <div className="file-info-item">
                    <div className="file-info-label">File ID</div>
                    <div className="file-info-value">{getFileInfo(formData.fileId).id}</div>
                  </div>
                  <div className="file-info-item">
                    <div className="file-info-label">Customer</div>
                    <div className="file-info-value">
                      {getFileInfo(formData.fileId).customerName || getFileInfo(formData.fileId).customer_name}
                    </div>
                  </div>
                  <div className="file-info-item">
                    <div className="file-info-label">Loan Type</div>
                    <div className="file-info-value">
                      {getFileInfo(formData.fileId).loanType || getFileInfo(formData.fileId).loan_type}
                    </div>
                  </div>
                  <div className="file-info-item">
                    <div className="file-info-label">Bank</div>
                    <div className="file-info-value">
                      {getFileInfo(formData.fileId).bankName || getFileInfo(formData.fileId).bank_name}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Additional Information */}
          <div className="form-section">
            <h2 className="section-title">Additional Information</h2>
            <div className="form-grid">
              <div className="form-group-full">
                <label className="form-label">Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  className="form-textarea"
                  placeholder="Add any additional details about this document..."
                />
              </div>

              <div className="form-group-full">
                <label className="form-label">Remark</label>
                <textarea
                  name="remark"
                  value={formData.remark}
                  onChange={handleChange}
                  className="form-textarea"
                  placeholder="Add any remarks or notes..."
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="form-actions">
            <button
              className="btn-cancel"
              onClick={() => {
                if (window.confirm("Discard changes?")) {
                  window.location.href = "/admin/documents";
                }
              }}
            >
              Cancel
            </button>
            <button
              className="btn-submit"
              onClick={handleSubmit}
              disabled={loading || files.length === 0}
            >
              {loading ? "Uploading..." : "📤 Upload Document"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default UploadDocument;