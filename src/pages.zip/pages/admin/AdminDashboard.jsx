import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/dashboard.css";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  Area,
  AreaChart,
} from "recharts";

const AdminDashboard = () => {
  const navigate = useNavigate();

  const [stats, setStats] = useState({
    total: 0,
    inProcess: 0,
    disbursement: 0,
    completed: 0,
    rejected: 0,
  });

  /* ---------------- SEED DATA (ONE TIME) ---------------- */
  useEffect(() => {
    if (!localStorage.getItem("users")) {
      localStorage.setItem(
        "users",
        JSON.stringify([
          { id: 1, role: "ADMIN" },
          { id: 2, role: "AGENT" },
          { id: 3, role: "AGENT" },
          { id: 4, role: "DATA_OPERATOR" },
          { id: 5, role: "BANK_EXECUTIVE" },
          { id: 6, role: "BANK_EXECUTIVE" },
        ])
      );
    }

    if (!localStorage.getItem("banks")) {
      localStorage.setItem(
        "banks",
        JSON.stringify([
          { id: 1, name: "HDFC", active: true },
          { id: 2, name: "ICICI", active: true },
          { id: 3, name: "SBI", active: true },
          { id: 4, name: "Axis", active: false },
        ])
      );
    }

    if (!localStorage.getItem("documents")) {
      localStorage.setItem(
        "documents",
        JSON.stringify([
          { id: 1, status: "Pending" },
          { id: 2, status: "Pending" },
          { id: 3, status: "Submitted" },
          { id: 4, status: "Verified" },
          { id: 5, status: "Rejected" },
          { id: 6, status: "Verified" },
        ])
      );
    }
  }, []);

  /* ---------------- LOAD LOAN STATS ---------------- */
  useEffect(() => {
    const loans = (JSON.parse(localStorage.getItem("loanFiles")) || []).filter(
      (l) => l.status !== "Deleted"
    );

    setStats({
      total: loans.length,
      inProcess: loans.filter((l) => l.status === "In-Process").length,
      disbursement: loans.filter((l) => l.status === "Is-Disbursement").length,
      completed: loans.filter((l) => l.status === "Completed").length,
      rejected: loans.filter((l) => l.status === "Rejected").length,
    });
  }, []);

  /* ---------------- USER STATS ---------------- */
  const users = JSON.parse(localStorage.getItem("users")) || [];

  const userStats = {
    totalUsers: users.length,
    agents: users.filter((u) => u.role === "AGENT").length,
    dataOperators: users.filter((u) => u.role === "DATA_OPERATOR").length,
    bankExecutives: users.filter((u) => u.role === "BANK_EXECUTIVE").length,
  };

  /* ---------------- BANK STATS ---------------- */
  const banks = JSON.parse(localStorage.getItem("banks")) || [];
  const loans = JSON.parse(localStorage.getItem("loanFiles")) || [];

  const totalBanks = banks.length;
  const activeBanks = banks.filter((b) => b.active).length;
  const inactiveBanks = banks.filter((b) => !b.active).length;

  const bankLoanCount = {};
  loans.forEach((loan) => {
    if (!loan.bankName) return;
    bankLoanCount[loan.bankName] = (bankLoanCount[loan.bankName] || 0) + 1;
  });

  const topBank =
    Object.keys(bankLoanCount).length > 0
      ? Object.keys(bankLoanCount).reduce((a, b) =>
          bankLoanCount[a] > bankLoanCount[b] ? a : b
        )
      : "N/A";

  /* ---------------- DOCUMENT STATS ---------------- */
  const documents = JSON.parse(localStorage.getItem("documents")) || [];

  const docStats = {
    pending: documents.filter((d) => d.status === "Pending").length,
    submitted: documents.filter((d) => d.status === "Submitted").length,
    verified: documents.filter((d) => d.status === "Verified").length,
    rejected: documents.filter((d) => d.status === "Rejected").length,
  };

  /* ---------------- COMMISSION SNAPSHOT ---------------- */
  const COMMISSION_RATE = 0.01;

  const disbursedLoans = loans.filter(
    (loan) => loan.status === "Is-Disbursement"
  );

  const totalCommission = disbursedLoans.reduce((sum, loan) => {
    const amount = Number(String(loan.amount).replace(/,/g, "") || 0);
    return sum + amount * COMMISSION_RATE;
  }, 0);

  const paidCommission = totalCommission * 0.7;
  const pendingCommission = totalCommission * 0.3;

  /* ---------------- CHART DATA ---------------- */
  const barData = [
    { name: "In-Process", value: stats.inProcess },
    { name: "Disbursement", value: stats.disbursement },
    { name: "Completed", value: stats.completed },
    { name: "Rejected", value: stats.rejected },
  ];

  const pieData = [
    { name: "In-Process", value: stats.inProcess, color: "#FF6B35" },
    { name: "Disbursement", value: stats.disbursement, color: "#004E89" },
    { name: "Completed", value: stats.completed, color: "#1FA883" },
    { name: "Rejected", value: stats.rejected, color: "#DC2626" },
  ];

  const trendData = [
    { month: "Jan", loans: 8, revenue: 450 },
    { month: "Feb", loans: 12, revenue: 680 },
    { month: "Mar", loans: 15, revenue: 820 },
    { month: "Apr", loans: 10, revenue: 590 },
    { month: "May", loans: 18, revenue: 950 },
    { month: "Jun", loans: 22, revenue: 1200 },
  ];

  const completionRate =
    stats.total > 0 ? ((stats.completed / stats.total) * 100).toFixed(1) : 0;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
        
        * {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .dashboard-container {
          min-height: 100vh;
          background: #f8fafc;
          padding: 1.5rem;
          max-width: 1400px;
          margin: 0 auto;
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          padding-bottom: 1.5rem;
          border-bottom: 1px solid #e2e8f0;
        }

        .header-content h1 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #0f172a;
          margin: 0 0 0.25rem 0;
          letter-spacing: -0.02em;
        }

        .header-content p {
          color: #64748b;
          font-size: 0.875rem;
          margin: 0;
          font-weight: 400;
        }

        .header-buttons {
          display: flex;
          gap: 0.75rem;
        }

        .create-btn, .logout-btn {
          padding: 0.625rem 1.25rem;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 600;
          font-size: 0.875rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .create-btn {
          background: #004E89;
          color: white;
          box-shadow: 0 1px 3px rgba(0, 78, 137, 0.2);
        }

        .create-btn:hover {
          background: #003d6e;
          box-shadow: 0 2px 6px rgba(0, 78, 137, 0.3);
        }

        .logout-btn {
          background: white;
          color: #64748b;
          border: 1px solid #e2e8f0;
        }

        .logout-btn:hover {
          background: #f8fafc;
          color: #DC2626;
          border-color: #DC2626;
        }

        /* Stats Grid */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .stat-card {
          background: white;
          border-radius: 12px;
          padding: 1.25rem;
          border: 1px solid #e2e8f0;
          transition: all 0.2s ease;
        }

        .stat-card:hover {
          border-color: #cbd5e1;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .stat-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.25rem;
          margin-bottom: 0.875rem;
          background: var(--accent-bg);
        }

        .stat-label {
          color: #64748b;
          font-size: 0.75rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 0.5rem;
        }

        .stat-value {
          font-size: 1.75rem;
          font-weight: 700;
          color: #0f172a;
          line-height: 1;
          font-family: 'JetBrains Mono', monospace;
        }

        .stat-trend {
          display: flex;
          align-items: center;
          gap: 0.25rem;
          margin-top: 0.625rem;
          font-size: 0.75rem;
          font-weight: 600;
        }

        .trend-up { color: #10b981; }
        .trend-down { color: #ef4444; }

        /* Insight Cards */
        .insight-cards {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .insight-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          border: 1px solid #e2e8f0;
          position: relative;
          overflow: hidden;
        }

        .insight-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--card-accent);
        }

        .insight-card h3 {
          font-size: 0.75rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #64748b;
          margin: 0 0 0.75rem 0;
        }

        .insight-value {
          font-size: 2rem;
          font-weight: 700;
          color: #0f172a;
          margin: 0 0 0.5rem 0;
          font-family: 'JetBrains Mono', monospace;
        }

        .insight-description {
          font-size: 0.8125rem;
          color: #64748b;
          line-height: 1.4;
        }

        /* Section Title */
        .section-title {
          font-size: 1.125rem;
          font-weight: 700;
          color: #0f172a;
          margin: 2rem 0 1rem 0;
          padding-left: 0.75rem;
          border-left: 3px solid #004E89;
        }

        /* Charts Grid */
        .charts-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .chart-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          border: 1px solid #e2e8f0;
        }

        .chart-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.25rem;
        }

        .chart-title {
          font-size: 0.9375rem;
          font-weight: 600;
          color: #0f172a;
          margin: 0;
        }

        .chart-badge {
          background: #f1f5f9;
          color: #64748b;
          padding: 0.25rem 0.625rem;
          border-radius: 6px;
          font-size: 0.6875rem;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          text-transform: uppercase;
        }

        /* Color Variants */
        .stat-card.total { --accent-bg: rgba(0, 78, 137, 0.08); }
        .stat-card.process { --accent-bg: rgba(255, 107, 53, 0.08); }
        .stat-card.disbursement { --accent-bg: rgba(0, 78, 137, 0.08); }
        .stat-card.completed { --accent-bg: rgba(16, 185, 129, 0.08); }
        .stat-card.rejected { --accent-bg: rgba(239, 68, 68, 0.08); }

        .insight-card:nth-child(1) { --card-accent: #004E89; }
        .insight-card:nth-child(2) { --card-accent: #10b981; }
        .insight-card:nth-child(3) { --card-accent: #f59e0b; }

        /* Responsive */
        @media (max-width: 1200px) {
          .stats-grid {
            grid-template-columns: repeat(3, 1fr);
          }
        }

        @media (max-width: 968px) {
          .dashboard-container {
            padding: 1rem;
          }

          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
          }

          .insight-cards {
            grid-template-columns: 1fr;
          }

          .charts-grid {
            grid-template-columns: 1fr;
          }

          .dashboard-header {
            flex-direction: column;
            align-items: stretch;
            gap: 1rem;
          }

          .header-buttons {
            width: 100%;
          }

          .create-btn, .logout-btn {
            flex: 1;
            justify-content: center;
          }
        }

        @media (max-width: 640px) {
          .stats-grid {
            grid-template-columns: 1fr;
          }

          .header-content h1 {
            font-size: 1.5rem;
          }
        }
      `}</style>

      <div className="dashboard-container">
        <div className="dashboard-header">
          <div className="header-content">
            <h1>Admin Dashboard</h1>
            <p>Comprehensive overview of loan operations and performance</p>
          </div>
          <div className="header-buttons">
            <button
              className="create-btn"
              onClick={() => navigate("/admin/create-loan")}
            >
              <span>➕</span>
              <span>Create Loan</span>
            </button>
            <button
              className="logout-btn"
              onClick={() => {
                sessionStorage.clear();
                navigate("/");
              }}
            >
              <span>🚪</span>
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* PRIMARY STATS */}
        <div className="stats-grid">
          <StatCard
            icon="📊"
            label="Total Loans"
            value={stats.total}
            trend="+12%"
            trendUp={true}
            variant="total"
          />
          <StatCard
            icon="⏳"
            label="In-Process"
            value={stats.inProcess}
            trend="+5%"
            trendUp={true}
            variant="process"
          />
          <StatCard
            icon="💰"
            label="Disbursement"
            value={stats.disbursement}
            trend="+8%"
            trendUp={true}
            variant="disbursement"
          />
          <StatCard
            icon="✅"
            label="Completed"
            value={stats.completed}
            trend="+15%"
            trendUp={true}
            variant="completed"
          />
          <StatCard
            icon="❌"
            label="Rejected"
            value={stats.rejected}
            trend="-3%"
            trendUp={false}
            variant="rejected"
          />
        </div>

        {/* KEY INSIGHTS */}
        <div className="insight-cards">
          <div className="insight-card">
            <h3>Completion Rate</h3>
            <div className="insight-value">{completionRate}%</div>
            <p className="insight-description">
              Success rate across all loan applications
            </p>
          </div>
          <div className="insight-card">
            <h3>Active Users</h3>
            <div className="insight-value">{userStats.totalUsers}</div>
            <p className="insight-description">
              Team members managing operations
            </p>
          </div>
          <div className="insight-card">
            <h3>Bank Partners</h3>
            <div className="insight-value">{activeBanks}/{totalBanks}</div>
            <p className="insight-description">
              Active banking partnerships
            </p>
          </div>
        </div>

        {/* PERFORMANCE ANALYTICS */}
        <h2 className="section-title">Performance Analytics</h2>
        <div className="charts-grid">
          <div className="chart-card">
            <div className="chart-header">
              <h3 className="chart-title">Loan Status Distribution</h3>
              <span className="chart-badge">Live</span>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={barData}>
                <XAxis
                  dataKey="name"
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <YAxis
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "white",
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {barData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        index === 0
                          ? "#FF6B35"
                          : index === 1
                          ? "#004E89"
                          : index === 2
                          ? "#10b981"
                          : "#ef4444"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <div className="chart-header">
              <h3 className="chart-title">Status Overview</h3>
              <span className="chart-badge">Real-Time</span>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  cx="50%"
                  cy="50%"
                  outerRadius={85}
                  innerRadius={55}
                  label={({ value }) => value > 0 ? value : ""}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "white",
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <div className="chart-header">
              <h3 className="chart-title">6-Month Loan Trend</h3>
              <span className="chart-badge">+45% Growth</span>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorLoans" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#004E89" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#004E89" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="month"
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <YAxis
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "white",
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="loans"
                  stroke="#004E89"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorLoans)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <div className="chart-header">
              <h3 className="chart-title">Revenue Performance</h3>
              <span className="chart-badge">₹12.8M YTD</span>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={trendData}>
                <XAxis
                  dataKey="month"
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <YAxis
                  stroke="#cbd5e1"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "white",
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    fontSize: 12 }}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ fill: "#10b981", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* TEAM OVERVIEW */}
        <h2 className="section-title">Team Overview</h2>
        <div className="stats-grid">
          <StatCard icon="👥" label="Total Users" value={userStats.totalUsers} variant="total" />
          <StatCard icon="🎯" label="Agents" value={userStats.agents} variant="process" />
          <StatCard icon="📝" label="Data Operators" value={userStats.dataOperators} variant="disbursement" />
          <StatCard icon="🏦" label="Bank Executives" value={userStats.bankExecutives} variant="completed" />
        </div>

        {/* BANK & DOCUMENTS */}
        <h2 className="section-title">Operations Status</h2>
        <div className="stats-grid">
          <StatCard icon="🏛️" label="Total Banks" value={totalBanks} variant="total" />
          <StatCard icon="✅" label="Active Banks" value={activeBanks} variant="completed" />
          <StatCard icon="⏸️" label="Inactive Banks" value={inactiveBanks} variant="rejected" />
          <StatCard icon="⏰" label="Pending Docs" value={docStats.pending} variant="process" />
          <StatCard icon="✓" label="Verified Docs" value={docStats.verified} variant="completed" />
        </div>

        {/* COMMISSION */}
        <h2 className="section-title">Commission Overview</h2>
        <div className="stats-grid">
          <StatCard
            icon="💰"
            label="Total Commission"
            value={`₹${(totalCommission/1000).toFixed(1)}K`}
            variant="total"
            isText={true}
          />
          <StatCard
            icon="✅"
            label="Paid"
            value={`₹${(paidCommission/1000).toFixed(1)}K`}
            variant="completed"
            isText={true}
          />
          <StatCard
            icon="⏳"
            label="Pending"
            value={`₹${(pendingCommission/1000).toFixed(1)}K`}
            variant="process"
            isText={true}
          />
          <StatCard
            icon="📋"
            label="Disbursed Files"
            value={disbursedLoans.length}
            variant="disbursement"
          />
        </div>
      </div>
    </>
  );
};

const StatCard = ({ icon, label, value, trend, trendUp, variant, isText }) => (
  <div className={`stat-card ${variant}`}>
    <div className="stat-icon">{icon}</div>
    <div className="stat-label">{label}</div>
    <div className="stat-value" style={isText ? { fontSize: '1.5rem', fontFamily: 'Inter' } : {}}>
      {value}
    </div>
    {trend && (
      <div className={`stat-trend ${trendUp ? "trend-up" : "trend-down"}`}>
        <span>{trendUp ? "↗" : "↘"}</span>
        <span>{trend}</span>
      </div>
    )}
  </div>
);

export default AdminDashboard;