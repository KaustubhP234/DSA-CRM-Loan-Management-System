import { useState } from "react";
import Navbar from "../components/Navbar";

const Home = () => {
  // EMI state
  const [amount, setAmount] = useState(7600000);
  const [rate, setRate] = useState(10.25);
  const [years, setYears] = useState(5);

  const monthlyRate = rate / 12 / 100;
  const months = years * 12;

  const emi =
    (amount * monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1);

  const totalPayable = emi * months;
  const interest = totalPayable - amount;

  const formatINR = (num) => "₹ " + Math.round(num).toLocaleString("en-IN");

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Plus Jakarta Sans', sans-serif;
          background: #ffffff;
          color: #1e293b;
          overflow-x: hidden;
        }

        /* ========== HERO SECTION ========== */
        .modern-hero {
          position: relative;
          min-height: 90vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f2a44 0%, #1a4d7a 100%);
          overflow: hidden;
        }

        .hero-bg-pattern {
          position: absolute;
          inset: 0;
          background-image: 
            radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.05) 1px, transparent 1px),
            radial-gradient(circle at 80% 80%, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
          background-size: 50px 50px;
          animation: patternMove 20s linear infinite;
        }

        @keyframes patternMove {
          from { transform: translate(0, 0); }
          to { transform: translate(50px, 50px); }
        }

        .hero-content-modern {
          position: relative;
          z-index: 2;
          max-width: 1200px;
          margin: 0 auto;
          padding: 4rem 2rem;
          text-align: center;
          animation: fadeInUp 1s ease-out;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .hero-badge {
          display: inline-block;
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          padding: 0.75rem 1.5rem;
          border-radius: 50px;
          color: #f5b400;
          font-weight: 700;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 2rem;
          border: 1px solid rgba(255, 255, 255, 0.2);
          animation: fadeIn 1.2s ease-out;
        }

        .hero-title {
          font-family: 'Space Grotesk', sans-serif;
          font-size: clamp(2.5rem, 5vw, 4.5rem);
          font-weight: 800;
          color: #ffffff;
          margin-bottom: 1.5rem;
          line-height: 1.1;
          letter-spacing: -0.02em;
          animation: fadeIn 1.4s ease-out;
        }

        .hero-subtitle {
          font-size: clamp(1rem, 2vw, 1.25rem);
          color: rgba(255, 255, 255, 0.85);
          max-width: 800px;
          margin: 0 auto 3rem;
          line-height: 1.7;
          animation: fadeIn 1.6s ease-out;
        }

        .hero-cta-group {
          display: flex;
          gap: 1.5rem;
          justify-content: center;
          flex-wrap: wrap;
          animation: fadeIn 1.8s ease-out;
        }

        .hero-btn {
          padding: 1rem 2.5rem;
          font-size: 1rem;
          font-weight: 700;
          border-radius: 50px;
          border: none;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .hero-btn-primary {
          background: linear-gradient(135deg, #f5b400, #ffc933);
          color: #0f2a44;
          box-shadow: 0 8px 24px rgba(245, 180, 0, 0.4);
        }

        .hero-btn-primary:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 32px rgba(245, 180, 0, 0.5);
        }

        .hero-btn-secondary {
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: #ffffff;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .hero-btn-secondary:hover {
          background: rgba(255, 255, 255, 0.25);
          border-color: rgba(255, 255, 255, 0.5);
        }

        /* ========== WHY CHOOSE US ========== */
        .why-modern {
          padding: 6rem 2rem;
          background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
        }

        .section-container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .section-badge {
          display: inline-block;
          background: linear-gradient(135deg, #fef3c7, #fde68a);
          color: #92400e;
          padding: 0.5rem 1.25rem;
          border-radius: 50px;
          font-weight: 700;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 1rem;
        }

        .section-title {
          font-family: 'Space Grotesk', sans-serif;
          font-size: clamp(2rem, 4vw, 3rem);
          font-weight: 800;
          color: #0f2a44;
          margin-bottom: 1rem;
          line-height: 1.2;
        }

        .section-description {
          font-size: 1.125rem;
          color: #64748b;
          max-width: 700px;
          margin: 0 auto 4rem;
          line-height: 1.7;
        }

        .features-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
          margin-top: 3rem;
        }

        .feature-card {
          background: white;
          padding: 2.5rem 2rem;
          border-radius: 20px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.06);
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          border: 1px solid rgba(226, 232, 240, 0.8);
          position: relative;
          overflow: hidden;
        }

        .feature-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 4px;
          background: var(--accent-gradient);
          transform: scaleX(0);
          transition: transform 0.4s;
        }

        .feature-card:hover::before {
          transform: scaleX(1);
        }

        .feature-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.12);
        }

        .feature-icon {
          width: 70px;
          height: 70px;
          margin: 0 auto 1.5rem;
          border-radius: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
          background: var(--accent-bg);
          color: var(--accent-color);
        }

        .feature-card h4 {
          font-size: 1.25rem;
          font-weight: 700;
          color: #0f2a44;
          margin-bottom: 0.875rem;
        }

        .feature-card p {
          color: #64748b;
          line-height: 1.6;
          font-size: 0.95rem;
        }

        /* Feature color variants */
        .feature-card:nth-child(1) {
          --accent-gradient: linear-gradient(135deg, #f59e0b, #fbbf24);
          --accent-bg: rgba(245, 158, 11, 0.1);
          --accent-color: #f59e0b;
        }

        .feature-card:nth-child(2) {
          --accent-gradient: linear-gradient(135deg, #10b981, #34d399);
          --accent-bg: rgba(16, 185, 129, 0.1);
          --accent-color: #10b981;
        }

        .feature-card:nth-child(3) {
          --accent-gradient: linear-gradient(135deg, #ef4444, #f87171);
          --accent-bg: rgba(239, 68, 68, 0.1);
          --accent-color: #ef4444;
        }

        .feature-card:nth-child(4) {
          --accent-gradient: linear-gradient(135deg, #8b5cf6, #a78bfa);
          --accent-bg: rgba(139, 92, 246, 0.1);
          --accent-color: #8b5cf6;
        }

        /* ========== LOAN PRODUCTS ========== */
        .products-modern {
          padding: 6rem 2rem;
          background: #0f2a44;
          color: white;
          text-align: center;
        }

        .products-modern .section-title {
          color: white;
        }

        .products-modern .section-description {
          color: rgba(255, 255, 255, 0.8);
        }

        .products-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 2rem;
          margin-top: 3rem;
        }

        .product-card-modern {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(10px);
          padding: 2.5rem 2rem;
          border-radius: 20px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          transition: all 0.4s;
          cursor: pointer;
        }

        .product-card-modern:hover {
          transform: translateY(-8px);
          background: rgba(255, 255, 255, 0.1);
          border-color: rgba(245, 180, 0, 0.5);
        }

        .product-icon-modern {
          width: 70px;
          height: 70px;
          margin: 0 auto 1.5rem;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
          background: linear-gradient(135deg, rgba(245, 180, 0, 0.2), rgba(255, 201, 51, 0.2));
          border: 2px solid rgba(245, 180, 0, 0.3);
        }

        .product-card-modern h4 {
          font-size: 1.25rem;
          font-weight: 700;
          margin-bottom: 0.875rem;
          color: #f5b400;
        }

        .product-card-modern p {
          color: rgba(255, 255, 255, 0.7);
          line-height: 1.6;
          font-size: 0.95rem;
        }

        /* ========== EMI CALCULATOR ========== */
        .emi-modern {
          padding: 6rem 2rem;
          background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
        }

        .emi-card {
          max-width: 1100px;
          margin: 3rem auto 0;
          background: white;
          border-radius: 24px;
          padding: 3rem;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
          border: 1px solid rgba(226, 232, 240, 0.8);
        }

        .emi-grid {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 3rem;
          align-items: start;
        }

        .emi-inputs {
          display: flex;
          flex-direction: column;
          gap: 2rem;
        }

        .input-group {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .input-label {
          font-weight: 700;
          color: #0f2a44;
          font-size: 0.95rem;
        }

        .input-field {
          padding: 0.875rem 1rem;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          font-size: 1rem;
          font-family: 'JetBrains Mono', monospace;
          transition: all 0.3s;
          width: 100%;
        }

        .input-field:focus {
          outline: none;
          border-color: #f5b400;
          box-shadow: 0 0 0 3px rgba(245, 180, 0, 0.1);
        }

        .range-slider {
          width: 100%;
          height: 8px;
          border-radius: 10px;
          background: #e2e8f0;
          outline: none;
          -webkit-appearance: none;
        }

        .range-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: linear-gradient(135deg, #f5b400, #ffc933);
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(245, 180, 0, 0.4);
        }

        .emi-results {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }

        .result-item {
          background: #f8fafc;
          padding: 1.5rem;
          border-radius: 16px;
          border-left: 4px solid var(--result-color);
        }

        .result-item h4 {
          font-size: 0.875rem;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 0.5rem;
        }

        .result-item p {
          font-size: 1.75rem;
          font-weight: 800;
          font-family: 'JetBrains Mono', monospace;
          color: #0f2a44;
        }

        .result-highlight {
          background: linear-gradient(135deg, #f5b400, #ffc933);
          border-left: none;
        }

        .result-highlight h4 {
          color: #92400e;
        }

        .result-highlight p {
          color: #0f2a44;
          font-size: 2.25rem;
        }

        .emi-chart {
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .donut-chart {
          width: 220px;
          height: 220px;
          border-radius: 50%;
          position: relative;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .donut-center {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          text-align: center;
          background: white;
          width: 140px;
          height: 140px;
          border-radius: 50%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }

        .donut-label {
          font-size: 0.75rem;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .donut-value {
          font-size: 1.5rem;
          font-weight: 800;
          font-family: 'JetBrains Mono', monospace;
          color: #0f2a44;
        }

        /* ========== TESTIMONIALS ========== */
        .testimonials-modern {
          padding: 6rem 2rem;
          background: white;
          text-align: center;
        }

        .testimonials-slider {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
          gap: 2rem;
          margin-top: 3rem;
          max-width: 1200px;
          margin-left: auto;
          margin-right: auto;
        }

        .testimonial-modern {
          background: linear-gradient(135deg, #f8fafc, #ffffff);
          padding: 2.5rem;
          border-radius: 20px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.06);
          border: 1px solid rgba(226, 232, 240, 0.8);
          text-align: left;
          transition: all 0.4s;
        }

        .testimonial-modern:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.12);
        }

        .testimonial-text {
          font-size: 1rem;
          line-height: 1.7;
          color: #475569;
          margin-bottom: 2rem;
          font-style: italic;
        }

        .testimonial-author {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .author-avatar {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(135deg, #0f2a44, #1a4d7a);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 1.25rem;
        }

        .author-info h4 {
          font-size: 1rem;
          font-weight: 700;
          color: #0f2a44;
          margin-bottom: 0.25rem;
        }

        .author-info span {
          font-size: 0.875rem;
          color: #64748b;
        }

        /* ========== CTA SECTION ========== */
        .cta-modern {
          padding: 6rem 2rem;
          background: linear-gradient(135deg, #0f2a44 0%, #1a4d7a 100%);
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .cta-modern::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image: 
            radial-gradient(circle at 20% 50%, rgba(245, 180, 0, 0.1) 1px, transparent 1px),
            radial-gradient(circle at 80% 80%, rgba(245, 180, 0, 0.1) 1px, transparent 1px);
          background-size: 50px 50px;
        }

        .cta-content-modern {
          position: relative;
          z-index: 2;
          max-width: 800px;
          margin: 0 auto;
        }

        .cta-modern .section-title {
          color: white;
          margin-bottom: 1.5rem;
        }

        .cta-modern .section-description {
          color: rgba(255, 255, 255, 0.85);
          margin-bottom: 3rem;
        }

        /* ========== FOOTER ========== */
        .footer-modern {
          background: #0a1929;
          color: rgba(255, 255, 255, 0.8);
          padding: 4rem 2rem 2rem;
        }

        .footer-grid {
          max-width: 1200px;
          margin: 0 auto 3rem;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 3rem;
        }

        .footer-col h3 {
          color: #f5b400;
          font-size: 1.25rem;
          margin-bottom: 1.5rem;
          font-weight: 800;
        }

        .footer-col h4 {
          color: white;
          font-size: 1rem;
          margin-bottom: 1.25rem;
          font-weight: 700;
        }

        .footer-col p {
          line-height: 1.7;
          font-size: 0.95rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .footer-col ul {
          list-style: none;
        }

        .footer-col ul li {
          margin-bottom: 0.75rem;
          color: rgba(255, 255, 255, 0.7);
          cursor: pointer;
          transition: all 0.3s;
          font-size: 0.95rem;
        }

        .footer-col ul li:hover {
          color: #f5b400;
          padding-left: 8px;
        }

        .footer-bottom {
          max-width: 1200px;
          margin: 0 auto;
          padding-top: 2rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          text-align: center;
          font-size: 0.875rem;
          color: rgba(255, 255, 255, 0.5);
        }

        /* ========== RESPONSIVE ========== */
        @media (max-width: 968px) {
          .emi-grid {
            grid-template-columns: 1fr;
          }

          .hero-cta-group {
            flex-direction: column;
          }

          .hero-btn {
            width: 100%;
          }
        }

        @media (max-width: 768px) {
          .modern-hero {
            min-height: 70vh;
          }

          .section-container {
            padding: 0 1rem;
          }

          .emi-card {
            padding: 2rem 1.5rem;
          }
        }
      `}</style>

      <Navbar />

      {/* HERO */}
      <section className="modern-hero">
        <div className="hero-bg-pattern"></div>
        <div className="hero-content-modern">
          <div className="hero-badge">🚀 Fintech Innovation</div>
          <h1 className="hero-title">
            District Service Agent<br />CRN Application
          </h1>
          <p className="hero-subtitle">
            A centralized fintech platform to manage customers, banks, loan files,
            documentation, commissions, and real-time performance tracking with
            enterprise-grade security and transparency.
          </p>
          <div className="hero-cta-group">
            <button className="hero-btn hero-btn-primary">Apply for Loan</button>
            <button className="hero-btn hero-btn-secondary">Talk to Expert</button>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="why-modern">
        <div className="section-container" style={{ textAlign: 'center' }}>
          <span className="section-badge">Why Choose Us</span>
          <h2 className="section-title">
            Smart, Secure & Trusted Loan Platform
          </h2>
          <p className="section-description">
            We simplify the entire loan journey with transparency, speed, and complete
            digital control for customers, DSAs, and banks.
          </p>

          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">⚡</div>
              <h4>Fast Approvals</h4>
              <p>Quick processing with real-time status tracking and instant notifications.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">🏦</div>
              <h4>Multiple Bank Options</h4>
              <p>Compare offers from multiple partnered banks for the best rates.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">🔐</div>
              <h4>Secure & Reliable</h4>
              <p>Enterprise-grade security with role-based access control.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h4>Complete Transparency</h4>
              <p>Track loan progress, commissions, and comprehensive reports.</p>
            </div>
          </div>
        </div>
      </section>

      {/* LOAN PRODUCTS */}
      <section className="products-modern">
        <div className="section-container">
          <span className="section-badge">Our Offerings</span>
          <h2 className="section-title">Loan Products We Provide</h2>
          <p className="section-description">
            Choose from a wide range of loan products designed to meet personal,
            professional, and business financial needs.
          </p>

          <div className="products-grid">
            <div className="product-card-modern">
              <div className="product-icon-modern">👤</div>
              <h4>Personal Loan</h4>
              <p>Unsecured loans for medical, travel, education, or emergencies.</p>
            </div>

            <div className="product-card-modern">
              <div className="product-icon-modern">🏠</div>
              <h4>Home Loan</h4>
              <p>Finance your dream home with flexible tenure and low interest.</p>
            </div>

            <div className="product-card-modern">
              <div className="product-icon-modern">💼</div>
              <h4>Business Loan</h4>
              <p>Grow your business with quick funding and easy documentation.</p>
            </div>

            <div className="product-card-modern">
              <div className="product-icon-modern">🔁</div>
              <h4>Balance Transfer</h4>
              <p>Transfer existing loans to lower interest rates.</p>
            </div>

            <div className="product-card-modern">
              <div className="product-icon-modern">🏦</div>
              <h4>Loan Against Property</h4>
              <p>Secure loans using residential or commercial property.</p>
            </div>

            <div className="product-card-modern">
              <div className="product-icon-modern">📈</div>
              <h4>Mortgage Loan</h4>
              <p>Long-term secured loans with higher eligibility limits.</p>
            </div>
          </div>
        </div>
      </section>

      {/* EMI CALCULATOR */}
      <section className="emi-modern">
        <div className="section-container" style={{ textAlign: 'center' }}>
          <span className="section-badge">Plan Your Loan</span>
          <h2 className="section-title">Personal Loans EMI Calculator</h2>
          <p className="section-description">
            Calculate your monthly EMI instantly with our easy-to-use calculator
          </p>

          <div className="emi-card">
            <div className="emi-grid">
              {/* INPUTS */}
              <div className="emi-inputs">
                <div className="input-group">
                  <label className="input-label">Loan Amount</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(+e.target.value)}
                    className="input-field"
                  />
                  <input
                    type="range"
                    min="100000"
                    max="10000000"
                    step="50000"
                    value={amount}
                    onChange={(e) => setAmount(+e.target.value)}
                    className="range-slider"
                  />
                </div>

                <div className="input-group">
                  <label className="input-label">Interest Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={rate}
                    onChange={(e) => setRate(+e.target.value)}
                    className="input-field"
                  />
                  <input
                    type="range"
                    min="5"
                    max="20"
                    step="0.1"
                    value={rate}
                    onChange={(e) => setRate(+e.target.value)}
                    className="range-slider"
                  />
                </div>

                <div className="input-group">
                  <label className="input-label">Loan Tenure (Years)</label>
                  <input
                    type="number"
                    value={years}
                    onChange={(e) => setYears(+e.target.value)}
                    className="input-field"
                  />
                  <input
                    type="range"
                    min="1"
                    max="30"
                    value={years}
                    onChange={(e) => setYears(+e.target.value)}
                    className="range-slider"
                  />
                </div>
              </div>

              {/* RESULTS */}
              <div className="emi-results">
                <div className="result-item" style={{ '--result-color': '#0f2a44' }}>
                  <h4>Principal Amount</h4>
                  <p>{formatINR(amount)}</p>
                </div>

                <div className="result-item" style={{ '--result-color': '#f5b400' }}>
                  <h4>Total Interest</h4>
                  <p>{formatINR(interest)}</p>
                </div>

                <div className="result-item" style={{ '--result-color': '#10b981' }}>
                  <h4>Total Payable</h4>
                  <p>{formatINR(totalPayable)}</p>
                </div>

                <div className="result-item result-highlight">
                  <h4>Monthly EMI</h4>
                  <p>{formatINR(emi)}</p>
                </div>
              </div>

              {/* CHART */}
              <div className="emi-chart">
                <div
                  className="donut-chart"
                  style={{
                    background: `conic-gradient(
                      #f5b400 ${(interest / totalPayable) * 360}deg,
                      #0f2a44 0deg
                    )`,
                  }}
                >
                  <div className="donut-center">
                    <div className="donut-label">Interest</div>
                    <div className="donut-value">
                      {((interest / totalPayable) * 100).toFixed(0)}%
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="testimonials-modern">
        <div className="section-container">
          <span className="section-badge">What Our Clients Say</span>
          <h2 className="section-title">Customer Testimonials</h2>
          <p className="section-description">
            Hear from our customers and partners who have successfully processed loans
            using our DSA CRN platform.
          </p>

          <div className="testimonials-slider">
            <div className="testimonial-modern">
              <p className="testimonial-text">
                "The loan process was extremely smooth and transparent. I could track
                every stage of my application in real time."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">A</div>
                <div className="author-info">
                  <h4>Amit Sharma</h4>
                  <span>Personal Loan Customer</span>
                </div>
              </div>
            </div>

            <div className="testimonial-modern">
              <p className="testimonial-text">
                "As a DSA, managing multiple customers and banks has become effortless.
                Commission tracking is very accurate."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">R</div>
                <div className="author-info">
                  <h4>Rohit Verma</h4>
                  <span>DSA Partner</span>
                </div>
              </div>
            </div>

            <div className="testimonial-modern">
              <p className="testimonial-text">
                "We are able to process loan files faster with proper documentation and
                status updates. A reliable CRM system."
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">S</div>
                <div className="author-info">
                  <h4>Sunita Iyer</h4>
                  <span>Bank Executive</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-modern">
        <div className="cta-content-modern">
          <h2 className="section-title">Ready to Get Your Loan Approved?</h2>
          <p className="section-description">
            Apply for a loan in just a few minutes with minimal documentation and
            real-time tracking.
          </p>
          <div className="hero-cta-group">
            <button className="hero-btn hero-btn-primary">Apply Now</button>
            <button className="hero-btn hero-btn-secondary">Talk to an Expert</button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer-modern">
        <div className="footer-grid">
          <div className="footer-col">
            <h3>DSA CRM Application</h3>
            <p>
              A secure and scalable fintech platform for managing loan applications,
              DSAs, bank partners, documentation, and commissions.
            </p>
          </div>

          <div className="footer-col">
            <h4>Quick Links</h4>
            <ul>
              <li>Home</li>
              <li>Our Services</li>
              <li>Loan Products</li>
              <li>Apply Loan</li>
              <li>Contact Us</li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Loan Products</h4>
            <ul>
              <li>Personal Loan</li>
              <li>Home Loan</li>
              <li>Business Loan</li>
              <li>Mortgage Loan</li>
              <li>Balance Transfer</li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Contact</h4>
            <p>📍 Sumago Infotech Pvt. Ltd, Nashik</p>
            <p>📞 +91 9607249676</p>
            <p>✉️ kaustubhpawar2021@gmail.com</p>
          </div>
        </div>

        <div className="footer-bottom">
          © 2025 DSA CRM Application | All Rights Reserved
        </div>
      </footer>
    </>
  );
};

export default Home;