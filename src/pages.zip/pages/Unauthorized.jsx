const Unauthorized = () => {
  return (
    <div style={{ padding: "40px" }}>
      <h1>Unauthorized</h1>
      <p>You do not have access to this page.</p>
    </div>
  );
};

export default Unauthorized;
