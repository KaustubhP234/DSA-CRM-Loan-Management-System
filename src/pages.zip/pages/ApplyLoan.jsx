const ApplyLoan = () => {
  return (
    <div style={{ padding: "80px", textAlign: "center" }}>
      <h1>Apply for Loan</h1>
      <p>Loan application form will be implemented here.</p>
    </div>
  );
};

export default ApplyLoan;
