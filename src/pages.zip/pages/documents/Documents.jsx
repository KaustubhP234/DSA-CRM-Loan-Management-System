const Documents = () => {
  return (
    <div>
      <h1>Documents</h1>
      <p>Loan documents will be managed here.</p>
    </div>
  );
};

export default Documents;
